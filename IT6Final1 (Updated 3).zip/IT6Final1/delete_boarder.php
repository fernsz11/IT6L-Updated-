<?php
include("db.php"); 

// Establish database connection
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}

// Get Boarder ID from URL
$Boarder_ID = $_GET['id'];

// Prepare the SQL statement to call the stored procedure
$sql = "CALL delete_boarder_and_related_data(?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind the parameter and execute the statement
    $stmt->bind_param("i", $Boarder_ID);
    if ($stmt->execute()) {
        // Redirect to the boarder list page after successful deletion
        header("Location: owner_boarder_list.php");
        exit;
    } else {
        die("Execution failed: " . $stmt->error);
    }
} else {
    die("Preparation failed: " . $conn->error);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
