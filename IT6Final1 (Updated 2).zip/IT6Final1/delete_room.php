<?php
include("database.php"); 
$conn = mysqli_connect($db_host,
                       $db_user, 
                       $db_pass, 
                       $db_name);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}

$Room_ID = $_GET['id'];

$sql = "DELETE FROM room WHERE Room_ID = '$Room_ID'";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}

header("Location: owner_room_list.php");
exit;
?>