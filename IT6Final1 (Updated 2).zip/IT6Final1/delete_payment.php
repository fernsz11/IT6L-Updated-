<?php
include("database.php"); 
$conn = mysqli_connect($db_host,
                       $db_user, 
                       $db_pass, 
                       $db_name);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}

$Payment_ID = $_GET['id'];

$sql = "DELETE FROM payment WHERE Payment_ID = '$Payment_ID'";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}

header("Location: owner_payment_list.php");
exit;
?>