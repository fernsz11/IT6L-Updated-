<?php
include("db.php"); 
$conn = mysqli_connect($db_host,
                       $db_user, 
                       $db_pass, 
                       $db_name);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}

$DepositBalance_ID = $_GET['id'];

$sql = "DELETE FROM deposit_balance WHERE DepositBalance_ID = '$DepositBalance_ID'";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}

header("Location: owner_deposit_list.php");
exit;
?>