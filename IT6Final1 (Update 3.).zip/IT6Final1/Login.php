<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
    
<div class ="container text-center">
    <div class = "row">

        <div class="col">
        
    </div>

<div class="col-lg-6">

    <form action="" method="post">
    <div class ="bg-light p-5 rounded mb-3 mt-3">
    <h2>Admin Login</h2>
    </div>
    <div class="form-floating mb-3">
    <input type="email" class="form-control" name="user" id="floatingInput" placeholder="name@example.com">
    <label for="floatingInput">Username</label>
    </div>

    <div class="form-floating mb-3">
    <input type="password" class="form-control" name="password" id="floatingPassword" placeholder="Password">
    <label for="floatingPassword">Password</label>
    </div>

    <div class="form-check d-md-flex justify-content-md-end mb-3">
  <input class="form-check-input" onclick='pass()' type="checkbox" value="" id="flexCheckDefault">
  <label class="form-check-label px-2" for="flexCheckDefault">Show Password</label>
    </div>  

    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
  <button class="btn btn-primary me-md-2" type="button">Login</button>
<button class="btn btn-primary" type="button" onclick="clearFields()">Clear</button>

    </div>
    </form>

</div>

    <div class="col">
        
    </div>

    </div>
</div>


<script>
    //show password
function pass() {
    const pass = document.getElementById('floatingPassword');
    if (pass.type === 'password') {
        pass.type = 'text';
    } else {
        pass.type = 'password';
    }
}

function clearFields() {
    document.getElementById('floatingInput').value = '';
    document.getElementById('floatingPassword').value = '';
}

function validateLogin() {
    const username = document.getElementsByName('user')[0].value;
    const password = document.getElementsByName('password')[0].value;
    const errorMessageDiv = document.createElement('div');

    if (username === 'caretaker' && password === 'caretaker123') {
        window.location.href = 'caretaker_dashboard.php';
    } else if (username === 'admin' && password === 'admin') {
        window.location.href = 'owner_dashboard.php';
    } else {
        errorMessageDiv.className = 'alert alert-danger';
        errorMessageDiv.innerText = 'Incorrect username or password.';
        document.querySelector('.bg-light').appendChild(errorMessageDiv);
    }
}

document.querySelector('button[type="button"]').addEventListener('click', validateLogin);

</script>

</body>
</html>


