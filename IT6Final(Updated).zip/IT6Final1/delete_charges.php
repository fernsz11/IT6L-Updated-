<?php
include("database.php"); 
$conn = mysqli_connect($db_host,
                       $db_user, 
                       $db_pass, 
                       $db_name);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}

$Charge_ID = $_GET['id'];

$sql = "DELETE FROM charges WHERE Charge_ID = '$Charge_ID'";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}

header("Location: owner_charge_list.php");
exit;
?>