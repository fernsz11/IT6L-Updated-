<?php
include("database.php"); 
$conn = mysqli_connect($db_host,
                       $db_user, 
                       $db_pass, 
                       $db_name);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}

$Booking_ID = $_GET['id'];

$sql = "DELETE FROM bookings WHERE Booking_ID = '$Booking_ID'";
$result = $conn->query($sql);

if (!$result) {
    die("Invalid query: " . $conn->error);
}

header("Location: owner_booking_list.php");
exit;
?>